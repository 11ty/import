window.YTD.tweets.part0 = [
  {
    "tweet" : {
      "id_str" : "2001",
      "created_at" : "Wed Oct 10 20:19:24 +0000 2018",
      "full_text" : "Eleventy &amp; friends with @eleven_ty and @nobody, read https://t.co/abc123 (email me@zachleat)",
      "entities" : {
        "urls" : [ { "url" : "https://t.co/abc123", "expanded_url" : "https://www.11ty.dev/docs/?a=1&b=2", "display_url" : "11ty.dev/docs/?a=1&b=2" } ],
        "user_mentions" : [ { "screen_name" : "eleven_ty", "id_str" : "2000" } ],
        "hashtags" : [ ]
      }
    }
  },
  {
    "tweet" : {
      "id_str" : "2002",
      "created_at" : "Thu Oct 11 20:19:24 +0000 2018",
      "full_text" : "A photo and a video\nSecond line https://t.co/media1",
      "entities" : {
        "urls" : [ ],
        "user_mentions" : [ ],
        "media" : [ { "url" : "https://t.co/media1", "type" : "photo", "media_url_https" : "https://pbs.twimg.com/media/Photo1.jpg" } ]
      },
      "extended_entities" : {
        "media" : [
          { "url" : "https://t.co/media1", "type" : "photo", "media_url_https" : "https://pbs.twimg.com/media/Photo1.jpg", "ext_alt_text" : "A \"photo\"" },
          { "url" : "https://t.co/media1", "type" : "video", "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/3/pu/img/Poster.jpg",
            "video_info" : { "variants" : [
              { "bitrate" : "2176000", "content_type" : "video/mp4", "url" : "https://video.twimg.com/ext_tw_video/3/pu/vid/1280x720/Big.mp4?tag=10" },
              { "bitrate" : "832000", "content_type" : "video/mp4", "url" : "https://video.twimg.com/ext_tw_video/3/pu/vid/640x360/Small.mp4?tag=10" },
              { "content_type" : "application/x-mpegURL", "url" : "https://video.twimg.com/ext_tw_video/3/pu/pl/Playlist.m3u8?tag=10" }
            ] } }
        ]
      }
    }
  },
  {
    "tweet" : {
      "id_str" : "2003",
      "created_at" : "Fri Oct 12 20:19:24 +0000 2018",
      "full_text" : "@zachleat Continuing the thread",
      "in_reply_to_status_id_str" : "2002",
      "in_reply_to_user_id_str" : "1000",
      "in_reply_to_screen_name" : "zachleat",
      "entities" : { "urls" : [ ], "user_mentions" : [ { "screen_name" : "zachleat", "id_str" : "1000" } ] }
    }
  },
  {
    "tweet" : {
      "id_str" : "2004",
      "created_at" : "Sat Oct 13 20:19:24 +0000 2018",
      "full_text" : "@eleven_ty A reply to someone else",
      "in_reply_to_status_id_str" : "1",
      "in_reply_to_user_id_str" : "2000",
      "entities" : { "urls" : [ ], "user_mentions" : [ { "screen_name" : "eleven_ty", "id_str" : "2000" } ] }
    }
  },
  {
    "tweet" : {
      "id_str" : "2005",
      "created_at" : "Sun Oct 14 20:19:24 +0000 2018",
      "full_text" : "RT @eleven_ty: A retweet",
      "entities" : { "urls" : [ ], "user_mentions" : [ { "screen_name" : "eleven_ty", "id_str" : "2000" } ] }
    }
  }
]
