window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "test@example.com",
      "createdVia" : "web",
      "username" : "zachleat",
      "accountId" : "1000",
      "createdAt" : "2008-01-01T00:00:00.000Z",
      "accountDisplayName" : "Zach Leatherman"
    }
  }
]
