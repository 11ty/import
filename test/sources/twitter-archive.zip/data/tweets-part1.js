window.YTD.tweets.part1 = [
  {
    "tweet" : {
      "id_str" : "2006",
      "created_at" : "Mon Oct 15 20:19:24 +0000 2018",
      "full_text" : "From the second part",
      "entities" : { "urls" : [ ], "user_mentions" : [ ] }
    }
  },
  {
    "tweet" : {
      "id_str" : "2007",
      "created_at" : "Tue Oct 16 20:19:24 +0000 2018",
      "full_text" : "@zachleat Thread photo https://t.co/media2",
      "in_reply_to_status_id_str" : "2003",
      "in_reply_to_user_id_str" : "1000",
      "entities" : { "urls" : [ ], "user_mentions" : [ { "screen_name" : "zachleat", "id_str" : "1000" } ] },
      "extended_entities" : { "media" : [ { "url" : "https://t.co/media2", "type" : "photo", "media_url_https" : "https://pbs.twimg.com/media/Photo2.jpg" } ] }
    }
  },
  {
    "tweet" : {
      "id_str" : "2008",
      "created_at" : "Wed Oct 17 20:19:24 +0000 2018",
      "full_text" : "@zachleat Reply to a deleted tweet",
      "in_reply_to_status_id_str" : "1999",
      "in_reply_to_user_id_str" : "1000",
      "entities" : { "urls" : [ ], "user_mentions" : [ { "screen_name" : "zachleat", "id_str" : "1000" } ] }
    }
  }
]
