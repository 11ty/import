window.YTD.tweets.part1 = [
  {
    "tweet" : {
      "id_str" : "2006",
      "created_at" : "Mon Oct 15 20:19:24 +0000 2018",
      "full_text" : "From the second part",
      "entities" : { "urls" : [ ], "user_mentions" : [ ] }
    }
  }
]
